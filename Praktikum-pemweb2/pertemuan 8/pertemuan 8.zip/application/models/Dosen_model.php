<?php
class Dosen_model extends CI_Model{
    public $id;
    public $nidn;
    public $nama;
    public $gender;
    public $pendidikan;
    public $prodi;
}